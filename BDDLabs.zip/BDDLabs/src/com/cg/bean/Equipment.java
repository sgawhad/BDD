package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Equipment {

	@FindBy(id = "purchaseMethod")
	private WebElement purchaseMethod;

	@FindBy(id = "seqNumber")
	private WebElement sequenceNumber;

	@FindBy(id = "deptId")
	private WebElement departmentId;

	@FindBy(id = "Status")
	private WebElement Status;

	@FindBy(id = "costCenter")
	private WebElement costCenter;

	@FindBy(id = "purchaseDate")
	private WebElement purchaseDate;

	@FindBy(id = "auditIndicator")
	private WebElement auditIndicator;

	@FindBy(id = "auditDate")
	private WebElement auditDate;
	
	@FindBy(id="submit")
	private WebElement submit;
	
	public String getPurchaseMethod() {
		return purchaseMethod.getAttribute("values");
	}

	public void setPurchaseMethod(String purchaseMethod) {
		this.purchaseMethod.sendKeys(purchaseMethod);
	}

	public String getSequenceNumber() {
		return sequenceNumber.getAttribute("values");
	}

	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber.sendKeys(sequenceNumber);
	}

	public String getDepartmentId() {
		return departmentId.getAttribute("values");
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId.sendKeys(departmentId);
	}

	public String getStatus() {
		return Status.getAttribute("values");
	}

	public void setStatus(String status) {
		this.Status.sendKeys(status);
	}

	public String getCostCenter() {
		return costCenter.getAttribute("values");
	}

	public void setCostCenter(String costCenter) {
		this.costCenter.sendKeys(costCenter);
	}

	public String getPurchaseDate() {
		return purchaseDate.getAttribute("values");
	}

	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate.sendKeys(purchaseDate);
	}

	public void auditIndicator() {
		auditIndicator.click();
	}

	public String getAuditDate() {
		return auditDate.getAttribute("value");
	}

	public void setAuditDate(String auditDate) {
		this.auditDate.sendKeys(auditDate);
	}


	
	public void submit() {
		submit.click();
	}

}

package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class User {

	@FindBy(id="userId")
	private WebElement userId;

	public String getUserId() {
		return userId.getAttribute("values");
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}
	
}

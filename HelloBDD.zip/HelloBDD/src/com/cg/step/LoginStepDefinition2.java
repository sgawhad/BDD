package com.cg.step;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Login;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition2 {

	private WebDriver driver;
	Login login;

	@Before
	public void init() {

		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();

	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Throwable {

		driver.get("file:///C:/Users/sgawhad/SpringWorkspace/HelloBDD/html/login.html");
		login = new Login();
		PageFactory.initElements(driver, login);
	}

	@When("^User select valid user$")
	public void user_select_valid_user() throws Throwable {
		login.selectUser(1);
	}

	@Then("^Validate user$")
	public void validate_user() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@When("^User enters valid username$")
	public void user_enters_valid_username() throws Throwable {
		login.selectUser(0);
		login.setUsername("abc");
	}

	@Then("^Validate username$")
	public void validate_username() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User enter valid password$")
	public void user_enter_valid_password() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("123");
	}

	@Then("^Validate password$")
	public void validate_password() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@When("^User select valid role$")
	public void user_select_valid_role() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("1234");
		login.selectRole(0);
	}

	@Then("^Validate role$")
	public void validate_role() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User submit form$")
	public void user_submit_form() throws Throwable {
		login.selectUser(0);
		login.setUsername("abcd");
		login.setPassword("1234");
		login.selectRole(1);
	}

	@Then("^Show successfull alert$")
	public void show_successfull_alert() throws Throwable {
		login.clickLogin();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

}

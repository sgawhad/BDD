package com.cg.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Login {

	@FindBy(id = "username")
	private WebElement username;

	@FindBy(id = "password")
	private WebElement password;

	@FindBy(id = "login")
	private WebElement login;

	@FindBy(id = "role")
	private WebElement role;

	@FindBy(id = "user")
	private List<WebElement> user;

	public void selectUser(int index) {
		this.user.get(index).click();
	}

	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void selectRole(int idx) {
		Select select = new Select(role);
		select.selectByIndex(idx);
	}

	public void clickLogin() {
		login.click();
	}

}
